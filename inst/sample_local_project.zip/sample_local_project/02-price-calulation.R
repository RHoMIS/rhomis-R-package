library(rhomis)

calculate_prices_csv(
    file_path="raw-data/raw-data.csv",
    id_type = "string",
    proj_id = "test_prj",
    form_id = "test_frm"
    )

